package com.example.nav_drawer.ui.category;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.nav_drawer.R;

public class category_details extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_security);
    }
}
