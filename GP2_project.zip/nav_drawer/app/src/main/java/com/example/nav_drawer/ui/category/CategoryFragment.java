package com.example.nav_drawer.ui.category;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.nav_drawer.R;

public class CategoryFragment extends Fragment {
    private Button button;
    private CategoryViewModel CategoryViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_category, container, false);
        /*هنا استخدمت اللست فيو */
        String[] mainItems = {"Design", "Database", "Network","Security","Programming"};


        ListView lv = (ListView) view.findViewById(R.id.mainmenu);


        ArrayAdapter<String> ListviewAdapter = new ArrayAdapter<String>(
                getActivity(),
                android.R.layout.simple_list_item_1,
                mainItems
        );
        lv.setAdapter(ListviewAdapter);


        //****************الى هناواللي تحت مطلوب عشان يشتغل الكود**************/

        CategoryViewModel =
                ViewModelProviders.of(this).get(CategoryViewModel.class);
        View root = inflater.inflate(R.layout.fragment_category, container, false);
        final TextView textView = root.findViewById(R.id.text_category);
        CategoryViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });

        return view;
    }
}

